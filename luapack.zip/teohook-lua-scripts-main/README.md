# teohook-lua-scripts
lua scripts for teohook

some might not work, but some small changes might fix it (you need to have some experience with lua for that)

Discord: Rayniel#2423

Asakin discord server: https://discord.gg/GtkEGqFb3f
