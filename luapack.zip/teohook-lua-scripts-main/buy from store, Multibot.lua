sendPacket("action|buy\nitem|upgrade_backpack", 2) --upgrades backpack

sendPacket("action|buy\nitem|vending_machine", 2) --buys a vending machine

sendPacket("action|buy\nitem|world_lock", 2) -- buys a worldlock



paste one of these lines in the executor on bots tab and press execute.

it is very easy to buy other things. just change the item name. you can find full name on items.dat